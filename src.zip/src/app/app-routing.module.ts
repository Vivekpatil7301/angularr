import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { ServicesComponent } from './services/services.component';
import { AuthguardGuard } from './guard/authguard.guard';
const routes: Routes = [
  {
    path:'app', children:[
    {
      path:'', redirectTo:'home', pathMatch:'full'
    },
    {
      path:'home', component:HomeComponent
    },
    {
      path:'about', component:AboutComponent
    }
    ,
    {
      path:'services',
  canActivate:[AuthguardGuard],
      component:ServicesComponent
    },
    {
      path:'**' ,component:PagenotfoundComponent
    }
    ]
  }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
