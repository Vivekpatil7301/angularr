import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MAT_DATE_FORMATS } from '@angular/material';


import { DatePipe } from '@angular/common';
import * as $ from 'jquery';
import { NgForm } from '@angular/forms'; //template form
import { FormControl, FormGroup,FormBuilder,Validators } from '@angular/forms'; //reavtive form
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [
    {
      provide: MAT_DATE_FORMATS, useValue: MAT_DATE_FORMATS
    }]
})
export class AppComponent {



  @Input() startDateLabel: string | undefined;
  @Input() endDateLabel: string | undefined;




  @Output() StartEndDatesOutput = new EventEmitter();
  startEndDatesForm: FormGroup | undefined;
getDates: any;
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.startEndDatesForm = this.fb.group({
      startDate: [''],
      endDate: [''],
      months: [5],
      days: [0],
      years: [0]
    });

  
  }

  startDateClicked() {
    this.StartEndDatesOutput.emit(this.getDates());
  }


  endDateClicked() {
    if (this.startEndDatesForm.controls['startDate'].value) {
      let eventStartTime = new Date(this.startEndDatesForm.controls['startDate'].value);
      let eventEndTime = new Date(this.startEndDatesForm.controls['endDate'].value);

      let m = moment(eventEndTime);
      let days = m.diff(eventStartTime, 'days');


      this.startEndDatesForm.controls['days'].setValue(days);
    } 
  }


}























  // title = 'angular_project';
 
  //  msg:string="This is the message";
  //   isvalid:boolean=true

  
  //   changevalue(valid=true){
  //     this.isvalid=valid
  //   }

    

  // isvalid:boolean=true;
  // changevalue(valid:boolean){
  //   this.isvalid=valid;
  // }
  // switchcase

  // public choose='';
  // setvalue(drp:any){
  //   this.choose=drp.target.value;
  // }

  
  //for loop database
  // students:any[]=[
  //   {
  //     'name':'aaa',
  //     'age':'21'
  //   },
  //   {
  //     'name':'bbb',
  //     'age':'22'
  //   },
  //   {
  //     'name':'ccc',
  //     'age':'23'
  //   },
  //   {
  //     'name':'ddd',
  //     'age':'24'
  //   },
  // ]

  // //trackby method
  // Students:any[]
  // constructor(){
  //   this.Students=[
  //     {
  //       studentid:1,
  //       name:"vishank",
  //       gender:"male",
  //       age:19,
  //       course:'fourth'
  //     },
  //     {
  //       studentid:2,
  //       name:"vihan",
  //       gender:"male",
  //       age:19,
  //       course:'fifth'
  //     },
  //     {
  //       studentid:3,
  //       name:"viahn",
  //       gender:"male",
  //       age:20,
  //       course:'sixth'
  //     },
  //     {
  //       studentid:4,
  //       name:"vishank",
  //       gender:"male",
  //       age:19,
  //       course:'seventh'
  //     }
  //   ]
  // }

  // getMoreStudentId():void{
  //   this.Students=[
      
  //       {
  //         studentid:1,
  //         name:"vishank",
  //         gender:"male",
  //         age:19,
  //         course:'fourth'
  //       },
  //       {
  //         studentid:2,
  //         name:"vihan",
  //         gender:"male",
  //         age:19,
  //         course:'fifth'
  //       },
  //       {
  //         studentid:3,
  //         name:"viahn",
  //         gender:"male",
  //         age:20,
  //         course:'sixth'
  //       },
  //       {
  //         studentid:4,
  //         name:"vishank",
  //         gender:"male",
  //         age:19,
  //         course:'seventh'
        
  //     },
  //     {
  //       studentid:5,
  //       name:"vishank",
  //       gender:"male",
  //       age:25,
  //       course:'tenenth'
  //     }
  //   ]
  // }
  // trackBystudentid(_index:number,student:any):string{
  //   return student.studentid
  // }
  













          // jquery code

    // public ngOnInit():void{
    //   $(document).ready(function(){
    //     $("button").click(function(){
    //       var div=$("div")
    //       div.animate({left:'100px'},3000)
    //       div.animate({fontSize:'5em'},2000)
    //     })
    //   })
    // }






    // image implimentation
    // firstimg:any='assets/nature.jpg';
    // alt:any="img is not available"
    // secimg:any='assets/cat.gif'

    //   pagetitle="simple data binding through interpolation"
      
    //   btnType:boolean=false;

    //   changeTitle(){
    //     this.pagetitle="interpolation using event binding"
    //   }

    //   name:string='';

    //     // template driven form

    //     Register(reg:NgForm){
    //       console.log
    //     }


                // reactive forms
 
            // form=new FormGroup({
            //   name :new FormControl('',Validators.compose([Validators.required,Validators.minLength(3),Validators.maxLength(50)])),
            //   email:new FormControl('',[Validators.required,Validators.email]),
            //   body:new FormControl ('',[Validators.required])
            //   })
            //   get f(){
            //     return this.form.controls;
            //   }
            //   submit(){
            //     console.log(this.form.value)
            //   }











  
