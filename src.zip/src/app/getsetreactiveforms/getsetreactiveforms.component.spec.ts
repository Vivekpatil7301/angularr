import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetsetreactiveformsComponent } from './getsetreactiveforms.component';

describe('GetsetreactiveformsComponent', () => {
  let component: GetsetreactiveformsComponent;
  let fixture: ComponentFixture<GetsetreactiveformsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetsetreactiveformsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetsetreactiveformsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
