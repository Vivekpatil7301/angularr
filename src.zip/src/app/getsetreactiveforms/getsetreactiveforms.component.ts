import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators,FormGroup,FormControl} from '@angular/forms';

@Component({
  selector: 'app-getsetreactiveforms',
  templateUrl: './getsetreactiveforms.component.html',
  styleUrls: ['./getsetreactiveforms.component.css']
})
export class GetsetreactiveformsComponent implements OnInit {

  signupForm!: FormGroup;
  firstName:string="";
  lastName:string="";
  Emaillist:string="";
  password:string="";

  constructor(private formBuilder:FormBuilder) { }


  ngOnInit(): void {
    this.signupForm=this.formBuilder.group({
      fname:['',[Validators.required]],
      lname:['',[Validators.required,Validators.maxLength(10)]],
      emailid:['',[Validators.required,Validators.email]],
      userpassword:['',[Validators.required]]
    });
  }
    PostData(){
      // this.FirstName=this.signupForm.get('fname')?.value
      // console.log(this.firstName)
      console.log(this.signupForm.value)
      
    }
    resetForm(){
      this.signupForm.reset();
    }
    //if we want to reset only some imput value then:
    // resetForm(){
    //   this.signupForm.reset({
    //     fname:'vishank',
    //     emalid:'xyz@gmai.com'
    //   });
    // }
fillData(){
  this.signupForm.patchValue({
    'emailid':'abc@gmail.com',
    'userpassword':'xyz'
  })
}
}
